
#include <iostream>
#include <ros/ros.h>
#include <serial/serial.h>
#include <std_msgs/String.h>
#include <std_msgs/Char.h>
#include <std_msgs/Empty.h>
#include <geometry_msgs/Twist.h>


//#Command to read address Address1:"A9FCFE73", Address2:"AAFCFE43", Address3:"ABFCFE52", Address4:"ACFCFE70", Address5:"ADFCFE61", Address6:"AEFCFE51", Address7:"AFFCFE40"
unsigned char address1[4] = {0xA9,0xFC,0xFE,0x73}; //Address 1
unsigned char address2[4] = {0xAA,0xFC,0xFE,0x43}; //Address 2
unsigned char address3[4] = {0xAB,0xFC,0xFE,0x52}; //Address 3
unsigned char address4[4] = {0xAC,0xFC,0xFE,0x70}; //Address 4
unsigned char address5[4] = {0xAD,0xFC,0xFE,0x61}; //Address 5
unsigned char address6[4] = {0xAE,0xFC,0xFE,0x51}; //Address 6
unsigned char address7[4] = {0xAF,0xFC,0xFE,0x40}; //Address 7

serial::Serial ser;
serial::Serial ser1;
serial::Serial ser2;
serial::Serial ser3;
serial::Serial ser4;

void write_callback(const std_msgs::String::ConstPtr& msg){
    ROS_INFO_STREAM("Writing to serial port" << msg->data);
    ser.write(msg->data);
}

int main (int argc, char** argv){
    ros::init(argc, argv, "serial_example_node");
    ros::NodeHandle nh;


    ros::Publisher pub = nh.advertise<geometry_msgs::Twist>("ultrasonic_dataccp", 1000);
    try
    {
        ser.setPort("/dev/ttyUSB0");
        ser.setBaudrate(19200);
        serial::Timeout to = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(to);
        ser.open();

        ser1.setPort("/dev/ttyUSB1");
        ser1.setBaudrate(19200);
        ser1.setTimeout(to);
        ser1.open();

        ser2.setPort("/dev/ttyUSB2");
        ser2.setBaudrate(19200);
        ser2.setTimeout(to);
        ser2.open();

        ser3.setPort("/dev/ttyUSB3");
        ser3.setBaudrate(19200);
        ser3.setTimeout(to);
        ser3.open();

        ser4.setPort("/dev/ttyUSB4");
        ser4.setBaudrate(19200);
        ser4.setTimeout(to);
        ser4.open();
    }
    catch (serial::IOException& e)
    {
        ROS_ERROR_STREAM("Unable to open port ");
        return -1;
    }

    if(ser.isOpen()){
        ROS_INFO_STREAM("Serial Port initialized");
    }else{
        return -1;
    }

    ros::Rate loop_rate(10);
    while(ros::ok()){

        ros::spinOnce();

	ser.write(address2,4);
	ser1.write(address3,4);
	ser2.write(address3,4);
	ser3.write(address1,4);
	ser4.write(address5,4);


	ROS_INFO_STREAM(ser.read());
	geometry_msgs::Twist msg;

        if(ser.available()){
            ROS_INFO_STREAM("Reading from serial port");
            std_msgs::String result;
            result.data = ser.read(ser.available());

            ROS_INFO_STREAM("Read: " << 1.6*int(uint8_t(result.data[3])) << " Raw: " << result.data);  //Position 3 is the position of the distance data

	    msg.linear.x = 1.6*int(uint8_t(result.data[3]));
        }

        if(ser1.available()){
            ROS_INFO_STREAM("Reading from serial port");
            std_msgs::String result1;
            result1.data = ser1.read(ser1.available());

            ROS_INFO_STREAM("Read1: " << 1.6*int(uint8_t(result1.data[4])) << " Raw1: " << result1.data);  //Position 4 is the position of the distance data

	    msg.linear.y = 1.6*int(uint8_t(result1.data[4]));
        }

        if(ser2.available()){
            ROS_INFO_STREAM("Reading from serial port");
            std_msgs::String result2;
            result2.data = ser2.read(ser2.available());

            ROS_INFO_STREAM("Read1: " << 1.6*int(uint8_t(result2.data[4])) << " Raw1: " << result2.data);  //Position 4 is the position of the distance data

	    msg.linear.z = 1.6*int(uint8_t(result2.data[4]));
        }

        if(ser3.available()){
            ROS_INFO_STREAM("Reading from serial port");
            std_msgs::String result3;
            result3.data = ser3.read(ser3.available());

            ROS_INFO_STREAM("Read1: " << 1.6*int(uint8_t(result3.data[4])) << " Raw1: " << result3.data);  //Position 4 is the position of the distance data

	    msg.angular.x = 1.6*int(uint8_t(result3.data[4]));
        }

        if(ser4.available()){
            ROS_INFO_STREAM("Reading from serial port");
            std_msgs::String result4;
            result4.data = ser4.read(ser4.available());

            ROS_INFO_STREAM("Read1: " << 1.6*int(uint8_t(result4.data[4])) << " Raw1: " << result4.data);  //Position 4 is the position of the distance data

	    msg.angular.y = 1.6*int(uint8_t(result4.data[4]));
        }
        pub.publish(msg);
        loop_rate.sleep();

    }
}

